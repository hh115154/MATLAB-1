function varargout = Storm_ID_GUI_Setup(varargin)
% STORM_ID_GUI_SETUP MATLAB code for Storm_ID_GUI_Setup.fig
%      STORM_ID_GUI_SETUP, by itself, creates a new STORM_ID_GUI_SETUP or raises the existing
%      singleton*.
%
%      H = STORM_ID_GUI_SETUP returns the handle to a new STORM_ID_GUI_SETUP or the handle to
%      the existing singleton*.
%
%      STORM_ID_GUI_SETUP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STORM_ID_GUI_SETUP.M with the given input arguments.
%
%      STORM_ID_GUI_SETUP('Property','Value',...) creates a new STORM_ID_GUI_SETUP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Storm_ID_GUI_Setup_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Storm_ID_GUI_Setup_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Storm_ID_GUI_Setup

% Last Modified by GUIDE v2.5 17-Jan-2011 17:01:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Storm_ID_GUI_Setup_OpeningFcn, ...
                   'gui_OutputFcn',  @Storm_ID_GUI_Setup_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Storm_ID_GUI_Setup is made visible.
function Storm_ID_GUI_Setup_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Storm_ID_GUI_Setup (see VARARGIN)

% Choose default command line output for Storm_ID_GUI_Setup
handles.output = hObject;

mainGuiInput = find(strcmp(varargin, 'Storm_ID_GUI_Main'));

% THIS IS WHERE IT OPNES THE MAIN GUI INDEPENDENTLY  :: FIX THIS!!!!
% ---------------------------------------------------------
% handles.MainGUI = Storm_ID_GUI_Main;  % stores handles of Main GUI
handles.MainGUI = varargin{mainGuiInput+1};

% mainHandles = guidata(handles.MainGUI);

% get main GUI position
% MainGUIPosition = get(mainHandles.figure1,'Position');
MainGUIPosition = getpixelposition(handles.MainGUI);
% get sub GUI position
SubGUIPosition = get(hObject,'Position');
% disp('original')
% disp(SubGUIPosition)

SubGUIPosition = [MainGUIPosition(1), MainGUIPosition(2), SubGUIPosition(3), ...
    SubGUIPosition(4)];
% SubGUIPosition = [0, 30, SubGUIPosition(3), SubGUIPosition(4)];
% disp('Main')
% disp(MainGUIPosition)
% disp('new')
% disp(SubGUIPosition)

set(hObject,'Position',SubGUIPosition);

% disp('new2')
% disp(get(hObject,'Position'))

handles.reset.edit_MinStormDur      = get(handles.edit_MinStormDur,'String');
handles.reset.edit_MinInterEventDur = get(handles.edit_MinInterEventDur,'String');
handles.reset.edit_MinStormVol      = get(handles.edit_MinStormVol,'String');
handles.reset.edit_NoPreDryDays     = get(handles.edit_NoPreDryDays,'String');
handles.reset.edit_estBaseGWI       = get(handles.edit_estBaseGWI,'String');
handles.reset.edit_TributaryArea    = get(handles.edit_TributaryArea,'String');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Storm_ID_GUI_Setup wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Storm_ID_GUI_Setup_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_MinStormDur_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MinStormDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MinStormDur as text
%        str2double(get(hObject,'String')) returns contents of edit_MinStormDur as a double


% --- Executes during object creation, after setting all properties.
function edit_MinStormDur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MinStormDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_MinInterEventDur_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MinInterEventDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MinInterEventDur as text
%        str2double(get(hObject,'String')) returns contents of edit_MinInterEventDur as a double


% --- Executes during object creation, after setting all properties.
function edit_MinInterEventDur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MinInterEventDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_MinStormVol_Callback(hObject, eventdata, handles)
% hObject    handle to edit_MinStormVol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_MinStormVol as text
%        str2double(get(hObject,'String')) returns contents of edit_MinStormVol as a double


% --- Executes during object creation, after setting all properties.
function edit_MinStormVol_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_MinStormVol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_NoPreDryDays_Callback(hObject, eventdata, handles)
% hObject    handle to edit_NoPreDryDays (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_NoPreDryDays as text
%        str2double(get(hObject,'String')) returns contents of edit_NoPreDryDays as a double


% --- Executes during object creation, after setting all properties.
function edit_NoPreDryDays_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_NoPreDryDays (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_TributaryArea_Callback(hObject, eventdata, handles)
% hObject    handle to edit_TributaryArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_TributaryArea as text
%        str2double(get(hObject,'String')) returns contents of edit_TributaryArea as a double


% --- Executes during object creation, after setting all properties.
function edit_TributaryArea_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_TributaryArea (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_reset.
function pushbutton_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit_MinStormDur,'String',handles.reset.edit_MinStormDur);
set(handles.edit_MinInterEventDur,'String',handles.reset.edit_MinInterEventDur);
set(handles.edit_MinStormVol,'String',handles.reset.edit_MinStormVol);
set(handles.edit_NoPreDryDays,'String',handles.reset.edit_NoPreDryDays);
set(handles.edit_estBaseGWI,'String',handles.reset.edit_estBaseGWI);
set(handles.edit_TributaryArea,'String',handles.reset.edit_TributaryArea);


% --- Executes on button press in pushbutton_Input.
function pushbutton_Input_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% % get the main GUI handle
% MainGUIhandles = Storm_ID_GUI_Main;

% get the data from Main handle
main = handles.MainGUI;

if ishandle(main)
    mainHandles = guidata(handles.MainGUI);
end
handles.Input.GUI_storm_duration = str2num(get(handles.edit_MinStormDur,'String'));
handles.Input.GUI_inter_event = str2num(get(handles.edit_MinInterEventDur,'String'));
handles.Input.GUI_storm_volume = str2num(get(handles.edit_MinStormVol,'String'));
handles.Input.GUI_iInterfaceDaysSinceRain = str2num(get(handles.edit_NoPreDryDays,'String'));
handles.Input.GUI_estBaseGWI = str2num(get(handles.edit_estBaseGWI,'String'));
handles.Input.GUI_Area = str2num(get(handles.edit_TributaryArea,'String'));

% This [mainHandles] is [handles] in main GUI!
% main GUI's handles is automatically updated by these lines below.
% mainHandles.test = 'sjb';
mainHandles.InputSetup = handles.Input;

% test change Main Window Value
% save back to Main GUI
guidata(Storm_ID_GUI_Main, mainHandles);

guidata(hObject, handles);




% --- Executes on button press in pushbutton_SelectData.
function pushbutton_SelectData_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_SelectData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


mainHandles = guidata(handles.MainGUI);

handles.Input = Select_Data_File;

% update filename in Main GUI
set(mainHandles.FileLocation,'String',[handles.Input.PathName handles.Input.FileNameDATA]);

% ---- Read Flow Meters schematic excel sheet



% update Sewershed name and Flow meter number in Sub GUI
set(handles.edit_meter_name,'String',[handles.Input.st_name ' -- ' handles.Input.st_num]);

guidata(hObject, handles);


function edit_estBaseGWI_Callback(hObject, eventdata, handles)
% hObject    handle to edit_estBaseGWI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_estBaseGWI as text
%        str2double(get(hObject,'String')) returns contents of edit_estBaseGWI as a double


% --- Executes during object creation, after setting all properties.
function edit_estBaseGWI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_estBaseGWI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Input = Select_Data_File
[FileNameDATA,PathName] = uigetfile( ...
    {'*.csv',  'comma separated variables (*.csv)'; ...
    '*.xlsx','Excel file (*.xlsx)'; ...
    '*.*',  'All Files (*.*)'}, ...
    'Pick a DATA file');
cd(PathName)

if ispc
    st_nameId = regexp(PathName, '\\', 'split');
    Input.st_name = st_nameId{end-1};
    
    st_numId = regexp(FileNameDATA,' ','split');
    Input.st_num = st_numId{1};  % str variable
else
    st_nameId = regexp(PathName, '/', 'split');
    Input.st_name = st_nameId{end-1};
    
    st_numId = regexp(FileNameDATA,' ','split');
    Input.st_num = st_numId{1};  % str variable
end


% set(handles.FileLocation,'string',[pwd '\' FileNameDATA]);  % 'Edit Text' object

Input.PathName = PathName;
Input.FileNameDATA = FileNameDATA;



function edit_meter_name_Callback(hObject, eventdata, handles)
% hObject    handle to edit_meter_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_meter_name as text
%        str2double(get(hObject,'String')) returns contents of edit_meter_name as a double


% --- Executes during object creation, after setting all properties.
function edit_meter_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_meter_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
